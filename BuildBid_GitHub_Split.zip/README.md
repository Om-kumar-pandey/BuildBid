# BuildBid Contractor Dashboard

## Project structure

- `index.html` — page structure/UI
- `styles.css` — all CSS styles
- `script.js` — all JavaScript logic

The files are split from the working single-file BuildBid dashboard without changing the existing UI/logic.

## Run locally

Open `index.html` in a browser, or use VS Code Live Server.

## Backend integration

Keep API calls and backend integration inside `script.js` (or later split it into modules/services as the project grows).
